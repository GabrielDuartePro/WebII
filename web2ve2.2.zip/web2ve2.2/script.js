
function mostrarModal() {
    var modal = document.getElementById("modal");
    modal.style.display = "block";
}

function fecharModal() {
    var modal = document.getElementById("modal");
    modal.style.display = "none";
}

function ordenar(tipo) {
    alert("Você escolheu ordenar " + tipo + ".");
    fecharModal();
}

function limparOrdenacao() {
    alert("Você escolheu limpar a ordenação.");
    fecharModal();
}

function mostrarFiltroModal() {
    var modal = document.getElementById("filtroModal");
    modal.style.display = "block";
}

function fecharFiltroModal() {
    var modal = document.getElementById("filtroModal");
    modal.style.display = "none";
}

function filtrarPorPreco() {
    var precoMinimo = document.getElementById("precoMinimo").value;
    var precoMaximo = document.getElementById("precoMaximo").value;
    
    // Adicione aqui o código para filtrar por preço
    alert("Você escolheu filtrar entre R$" + precoMinimo + " e R$" + precoMaximo + ".");
    fecharFiltroModal();
}

function limparFiltro() {
    document.getElementById("precoMinimo").value = "";
    document.getElementById("precoMaximo").value = "";
    // Adicione aqui o código para limpar o filtro
    alert("Você escolheu limpar o filtro.");
    fecharFiltroModal();
}


