# WebII
Trabalho de Web II.
Faremos nossa parte, que será:<br>
Design do Front-end (HTML/CSS/JavaScript):<br>
Crie um design básico do front-end que inclua as páginas relevantes para o teste, como a página inicial, página de produtos e um "carrinho de compras" simples. Não é necessário um design complexo, mas certifique-se de que o front-end reflita as funcionalidades que você deseja testar.<br>
Faremos o seguinte: página inicial, onde aparecerá produtos; e faremos a página do "carrinho de compras" onde aparecerá os produtos selecionados e, resumidamente, um botão "Finalizar Compra", que, então, finalizará o programa com uma tela dizendo "Compra finalizada!".<br>